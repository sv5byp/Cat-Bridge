﻿SV5BYP's Cat Bridge 3.31 - Logger32 utility

Close Cat Bridge and all applications connected to it. Keep a backup of the old folder. Extract ALL nine files into the SAME permanent Bridge folder, replacing program files while retaining existing personal files and activation backups. Do not run from inside the ZIP. Run SV5BYP's Cat Bridge.exe; it starts minimized. Logger32 can remain open.

CONNECTIONS
Ham Radio Deluxe: 127.0.0.1:7809 or 127.0.0.1:4533.
Hamlib NET rigctl: 127.0.0.1:4533. OmniRig: Rig 1 with CAT PTT.
Keep the radio configured in Logger32. When the radio uses a generic DIG mode, select Mode None / no automatic mode changes in the client application. This bridge does not change the radio's modulation mode.

GENERIC DIG COMPATIBILITY
Logger32's generic DIG label is preserved as DIG over HRD. It does not prove upper or lower sideband. Hamlib receives its unspecified mode and OmniRig receives PM_UNKNOWN; frequency and CAT PTT remain available. Explicit USB, LSB, DATA-U and DATA-L aliases keep their previous interpretation. No radio mode is silently changed and no USB/LSB sideband is invented. A tone-to-RF calculation cannot be supplied by OmniRig for generic DIG until its sideband is known.

DIAGNOSTICS
Open the small ... tools menu and choose Diagnostics / Create report. CatBridge-Diagnostic.txt is written beside the program. The on-demand tool does not open serial ports, key PTT, retune, register OmniRig or change preferences. It includes bounded logs and sanitized Logger32 PTT acknowledgement text. Acknowledgements do not establish physical radio TX. Automatic diagnostic transmission is not included in this release; no reports are uploaded.

PTT AND OWNERSHIP
PTT can use Logger32, a separate physical serial port with DTR/RTS, or Off. The serial PTT port must not be the CAT port already opened by Logger32. Use a PTT route supported by the radio/cable and Logger32. The first real frequency/PTT writer controls the radio until that client's connection closes; passive readers do not claim it. Only the owner is green. The continuous PTT limit remains three minutes. Reconnection never replays PTT automatically.

COMPATIBILITY
Managed program, updater and Setup compile against official .NET Framework 4.0 references. This is an x64 package. Actual Windows 7 / FT-897D radio validation remains pending. Secure online updates require TLS 1.2 and normal certificates; old runtimes may need a supported newer .NET or manual ZIP downloads. TLS failure does not disable CAT/PTT. Same-folder OmniRig updates normally need no reactivation; existing conflicting routing requires the existing explicit Activate review.

Software validation uses simulated hardware. Confirm operation with your actual radio and interface. Preserve the included licenses. Independent SV5BYP utility, not an official Logger32 or HRD product.
