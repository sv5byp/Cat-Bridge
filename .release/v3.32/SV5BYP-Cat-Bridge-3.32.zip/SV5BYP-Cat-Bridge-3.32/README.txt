﻿SV5BYP's Cat Bridge 3.32 - Logger32 utility

PORTABLE
Extract all nine files into one permanent folder and run SV5BYP's Cat Bridge.exe. No installer is required. Do not run inside the ZIP. For an update, close Bridge and all connected client applications, back up the folder, and replace the nine program files in the SAME folder. Keep personal files, reports and OmniRig activation backups. Logger32 may remain open. The program starts minimized.

CONNECTIONS
Configure the radio in Logger32. Applications can use Ham Radio Deluxe (127.0.0.1:7809 or 127.0.0.1:4533), Hamlib NET rigctl (127.0.0.1:4533), or OmniRig Rig 1 with CAT PTT. The first client requesting a real frequency/PTT change controls the radio until that connection closes. Passive reading does not claim control; only the owner is green. Generic DIG has no assumed sideband. Select Mode None / no automatic mode changes in the client; configure the physical mode in Logger32.

LOCAL DIAGNOSTICS - ALWAYS AVAILABLE
The ordinary local log remains active. CatBridge-Diagnostic.txt is created automatically at startup and refreshed after captured errors, even when automatic sending is OFF. Bursts are combined; refresh may take about 30 seconds. The file is written beside the program, or to %LOCALAPPDATA%/SV5BYP/Cat Bridge/Diagnostics if the program folder cannot be written. The ... tools menu also provides Diagnostics / Create report. Local reports can contain detailed paths, port information and logs: review them before sharing manually. Report creation does not open serial ports, key PTT or retune the radio.

OPTIONAL AUTOMATIC ERROR REPORTS
Sending is OFF by default. In the ... tools menu, enable Automatic error reports only after reading and accepting the consent notice. Only minimized error summaries are sent to the developer's GlitchTip project in the EU. They contain the error category, program/Windows/.NET versions, CAT/PTT state and application method names. They do NOT include exception messages, full logs, callsigns, contacts, passwords, usernames, paths or device identifiers. The service receives the network IP when connecting. The complete CatBridge-Diagnostic.txt file is never uploaded automatically.

At most five distinct error categories per day are queued, up to twenty pending records, retained for up to seven days with bounded retries. Turning sending OFF cancels active sending and removes queued upload copies; the ordinary local log and diagnostic file remain. A service/network failure does not stop CAT/PTT. Send synthetic test report is available only after consent. Error reporting privacy reopens the disclosure. The DSN is a public ingestion key, not an account password or access to read the reports.

PTT
Use Logger32 PTT, a separate physical serial DTR/RTS PTT port, or Off as required by the radio and interface. Do not select the CAT port already opened by Logger32 for serial PTT. The continuous PTT limit is three minutes. Reconnection does not replay PTT. Command acknowledgement alone does not establish physical radio transmission.

COMPATIBILITY AND UPDATES
This is an x64 package. Managed programs compile against .NET Framework 4.0 APIs. Secure updates and automatic sending require TLS 1.2 and valid certificates. Older systems may need a supported newer .NET Framework or manual ZIP updates. No insecure TLS fallback is used; CAT/PTT and local diagnostics remain independent. Automatic updates wait until client applications disconnect and PTT is released. Same-folder OmniRig updates normally need no reactivation; conflicting routing requires explicit review in OmniRig Setup.

Software validation uses simulated hardware. Confirm operation with the actual radio and interface. Keep the included licenses and third-party notices. Independent SV5BYP utility, not an official Logger32 or HRD product.
Official downloads: https://github.com/sv5byp/Cat-Bridge/releases/latest
